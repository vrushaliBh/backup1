function Footer () { 
        return ( <p>copyright :All rights reserved 2021</p> );
    }
//  console.log("H")
export default Footer;